package br.com.erudio.configs;

public class TestConfigs {

	public static final int SERVER_PORT = 8888;
}
